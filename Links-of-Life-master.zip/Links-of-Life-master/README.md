# Links-of-Life
This will be one of the outcomes of the repository "It is what you make of it!" and will be set up like a clip board app, so that enteries can be formulated, then copied into designated areas, with ease.
