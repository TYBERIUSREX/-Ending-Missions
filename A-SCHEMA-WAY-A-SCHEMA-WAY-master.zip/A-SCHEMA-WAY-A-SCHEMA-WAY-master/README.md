# A-SCHEMA-WAY-A-SCHEMA-WAY
Schema Text Ending
" It Is What You Make of It ! "
